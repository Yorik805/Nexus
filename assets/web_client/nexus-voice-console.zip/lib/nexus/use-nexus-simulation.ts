'use client'

/**
 * useNexusSimulation
 * ------------------
 * Central mock state machine for the console. EVERYTHING here is simulated.
 *
 * Integration seams (replace mock producers, keep the return shape):
 *   - connection / retry()      ->  real Nexus HTTP health + reconnect
 *   - micEnabled / toggleMic()  ->  real getUserMedia permission + stream
 *   - voiceState transitions    ->  real VAD + speech recognition + TTS events
 *   - liveTranscript            ->  real speech-to-text partial results
 *   - spokenResponse            ->  real TTS "currently speaking" text
 *   - events                    ->  real Nexus runtime event stream
 *   - interactions              ->  real request/response pairs
 *   - latencyMs                 ->  real measured round-trip latency
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  MOCK_SCENARIOS,
  nextId,
  seedEvents,
  seedInteractions,
} from './mock-data'
import type {
  ConnectionState,
  Interaction,
  NexusEvent,
  VoiceState,
} from './types'

const MAX_EVENTS = 60
const MAX_INTERACTIONS = 6

export function useNexusSimulation() {
  const [connection, setConnection] = useState<ConnectionState>('connected')
  const [micEnabled, setMicEnabled] = useState(true)
  const [voiceState, setVoiceStateRaw] = useState<VoiceState>('listening')
  const [liveTranscript, setLiveTranscript] = useState('')
  const [spokenResponse, setSpokenResponse] = useState('')
  // Seed data is created on the client (see effect below) to avoid SSR/CSR
  // hydration mismatches from time-based values.
  const [events, setEvents] = useState<NexusEvent[]>([])
  const [interactions, setInteractions] = useState<Interaction[]>([])
  const [latencyMs, setLatencyMs] = useState(42)
  const [lastCommunication, setLastCommunication] = useState(0)
  const [autoRun, setAutoRun] = useState(true)

  const timers = useRef<ReturnType<typeof setTimeout>[]>([])
  const scenarioIndex = useRef(0)

  const clearTimers = useCallback(() => {
    timers.current.forEach(clearTimeout)
    timers.current = []
  }, [])

  const schedule = useCallback((fn: () => void, ms: number) => {
    const t = setTimeout(fn, ms)
    timers.current.push(t)
    return t
  }, [])

  const pushEvent = useCallback(
    (e: Pick<NexusEvent, 'category' | 'label' | 'description'>) => {
      setEvents((prev) => {
        const next = [
          ...prev,
          { ...e, id: nextId('evt'), timestamp: Date.now() },
        ]
        return next.slice(-MAX_EVENTS)
      })
      setLastCommunication(Date.now())
    },
    [],
  )

  const addInteraction = useCallback(
    (role: Interaction['role'], text: string) => {
      setInteractions((prev) => {
        const next = [
          ...prev,
          { id: nextId('int'), role, text, timestamp: Date.now() },
        ]
        return next.slice(-MAX_INTERACTIONS)
      })
    },
    [],
  )

  // --- Seed on mount (client only) ----------------------------------------
  useEffect(() => {
    const now = Date.now()
    setEvents(seedEvents(now))
    setInteractions(seedInteractions(now))
    setLastCommunication(now)
  }, [])

  // --- Mock latency jitter -------------------------------------------------
  useEffect(() => {
    if (connection !== 'connected') return
    const interval = setInterval(() => {
      setLatencyMs(() => 36 + Math.round(Math.random() * 18))
    }, 2600)
    return () => clearInterval(interval)
  }, [connection])

  // --- The scripted voice loop --------------------------------------------
  useEffect(() => {
    clearTimers()

    if (!autoRun) return
    if (connection !== 'connected') {
      setVoiceStateRaw(connection === 'error' ? 'error' : 'idle')
      return
    }
    if (!micEnabled) {
      setVoiceStateRaw('mic_disabled')
      return
    }

    let cancelled = false

    const runScenario = () => {
      if (cancelled) return
      const scenario = MOCK_SCENARIOS[scenarioIndex.current % MOCK_SCENARIOS.length]

      // Phase 1: listening
      setVoiceStateRaw('listening')
      setLiveTranscript('')
      setSpokenResponse('')

      // Phase 2: user speaking — stream the transcription word by word
      schedule(() => {
        setVoiceStateRaw('user_speaking')
        const words = scenario.userUtterance.split(' ')
        words.forEach((_, i) => {
          schedule(
            () => setLiveTranscript(words.slice(0, i + 1).join(' ')),
            i * 130,
          )
        })
        const speakDur = words.length * 130 + 700

        // Phase 3: processing — emit runtime events in sequence
        schedule(() => {
          addInteraction('user', scenario.userUtterance)
          setLiveTranscript('')
          setVoiceStateRaw('processing')
          scenario.events.forEach((e, i) => {
            schedule(() => pushEvent(e), i * 620)
          })
          const processDur = scenario.events.length * 620 + 500

          // Phase 4: Nexus speaking — stream the response.
          // The mic stays live the whole time (barge-in ready), so on some
          // turns the user interrupts mid-sentence and Nexus stops to listen.
          schedule(() => {
            setVoiceStateRaw('nexus_speaking')
            setSpokenResponse(scenario.nexusResponse)
            addInteraction('nexus', scenario.nexusResponse)
            const talkDur = 2600 + scenario.nexusResponse.length * 22
            const willBargeIn = scenarioIndex.current % 2 === 1

            if (willBargeIn) {
              // User speaks over Nexus → speech halts, mic re-engages.
              schedule(() => {
                setVoiceStateRaw('interruption')
                setSpokenResponse('')
                pushEvent({
                  category: 'event',
                  label: 'BARGE_IN',
                  description: 'User spoke over playback — halting speech',
                })
                schedule(() => {
                  scenarioIndex.current += 1
                  runScenario()
                }, 1500)
              }, Math.round(talkDur * 0.45))
            } else {
              // Nexus finishes, then loop to the next turn.
              schedule(() => {
                setSpokenResponse('')
                scenarioIndex.current += 1
                runScenario()
              }, talkDur)
            }
          }, processDur)
        }, speakDur)
      }, 2200)
    }

    runScenario()

    return () => {
      cancelled = true
      clearTimers()
    }
  }, [autoRun, connection, micEnabled, clearTimers, schedule, pushEvent, addInteraction])

  // --- Manual controls (mock behaviors) -----------------------------------
  const toggleMic = useCallback(() => {
    setMicEnabled((prev) => !prev)
  }, [])

  const retry = useCallback(() => {
    clearTimers()
    setConnection('retrying')
    pushEvent({ category: 'event', label: 'RECONNECT', description: 'Attempting to reach Nexus runtime' })
    schedule(() => {
      setConnection('connected')
      setLastCommunication(Date.now())
      pushEvent({ category: 'result', label: 'CONNECTED', description: 'Runtime handshake complete' })
    }, 1600)
  }, [clearTimers, schedule, pushEvent])

  const stopSpeaking = useCallback(() => {
    if (voiceState !== 'nexus_speaking') return
    clearTimers()
    setSpokenResponse('')
    pushEvent({ category: 'event', label: 'TTS_STOP', description: 'Playback stopped by user' })
    scenarioIndex.current += 1
    setVoiceStateRaw('listening')
    // Nudge the loop back to life
    schedule(() => setVoiceStateRaw('listening'), 50)
  }, [voiceState, clearTimers, schedule, pushEvent])

  const triggerInterruption = useCallback(() => {
    if (voiceState !== 'nexus_speaking') return
    clearTimers()
    setVoiceStateRaw('interruption')
    setSpokenResponse('')
    pushEvent({ category: 'event', label: 'BARGE_IN', description: 'User interrupted — pausing speech' })
    schedule(() => setVoiceStateRaw('listening'), 1800)
  }, [voiceState, clearTimers, schedule, pushEvent])

  /**
   * Demo-only override so a reviewer can preview any state. In the real
   * console the voice/connection state is derived from Nexus + mic events,
   * not set manually.
   */
  const previewConnection = useCallback(
    (c: ConnectionState) => {
      setAutoRun(false)
      clearTimers()
      setConnection(c)
    },
    [clearTimers],
  )

  const previewVoiceState = useCallback(
    (s: VoiceState) => {
      setAutoRun(false)
      clearTimers()
      setSpokenResponse(s === 'nexus_speaking' ? MOCK_SCENARIOS[0].nexusResponse : '')
      setLiveTranscript(s === 'user_speaking' ? MOCK_SCENARIOS[0].userUtterance : '')
      setVoiceStateRaw(s)
    },
    [clearTimers],
  )

  const resumeAuto = useCallback(() => {
    scenarioIndex.current += 1
    setConnection('connected')
    setMicEnabled(true)
    setAutoRun(true)
  }, [])

  return {
    // state
    connection,
    micEnabled,
    voiceState,
    liveTranscript,
    spokenResponse,
    events,
    interactions,
    latencyMs,
    lastCommunication,
    autoRun,
    // actions
    toggleMic,
    retry,
    stopSpeaking,
    triggerInterruption,
    previewConnection,
    previewVoiceState,
    resumeAuto,
    setAutoRun,
  }
}

export type NexusSimulation = ReturnType<typeof useNexusSimulation>
