/**
 * MOCK DATA for the Nexus Voice Console prototype.
 * ------------------------------------------------
 * None of this is real. A future integration should delete this file and
 * source equivalent data from the live Nexus runtime.
 */
import type { EventCategory, Interaction, NexusEvent } from './types'

let idCounter = 0
export function nextId(prefix = 'id'): string {
  idCounter += 1
  return `${prefix}-${idCounter}-${Math.random().toString(36).slice(2, 7)}`
}

/**
 * A single scripted voice interaction used to drive the simulated state
 * machine. Represents one full loop: user speaks → Nexus processes → Nexus
 * replies. Replace with real recognition + API results.
 */
export interface MockScenario {
  /** What the mock "user" says (streamed word-by-word as transcription). */
  userUtterance: string
  /** What mock Nexus "speaks" back. */
  nexusResponse: string
  /** Runtime events emitted during the processing phase, in order. */
  events: { category: EventCategory; label: string; description: string }[]
}

export const MOCK_SCENARIOS: MockScenario[] = [
  {
    userUtterance: 'Hey Nexus, start the development server.',
    nexusResponse: 'The development server has been started successfully on port 3000.',
    events: [
      { category: 'event', label: 'USER_EVENT', description: 'Voice request received' },
      { category: 'orchestrator', label: 'ORCHESTRATOR', description: 'Creating execution plan' },
      { category: 'validator', label: 'VALIDATOR', description: 'Execution plan validated' },
      { category: 'plugin', label: 'terminal.EXECUTE', description: 'Running "pnpm dev"' },
      { category: 'result', label: 'RESULT', description: 'Process started successfully' },
    ],
  },
  {
    userUtterance: 'Show me the status of the deployment pipeline.',
    nexusResponse: 'The latest deployment finished two minutes ago and all checks passed.',
    events: [
      { category: 'event', label: 'USER_EVENT', description: 'Voice request received' },
      { category: 'orchestrator', label: 'ORCHESTRATOR', description: 'Resolving intent: pipeline.status' },
      { category: 'validator', label: 'VALIDATOR', description: 'Scope check passed' },
      { category: 'plugin', label: 'ci.QUERY', description: 'Fetching pipeline state' },
      { category: 'result', label: 'RESULT', description: 'All checks passed' },
    ],
  },
  {
    userUtterance: 'Run the test suite and summarize any failures.',
    nexusResponse: 'All 142 tests passed. There were no failures to report.',
    events: [
      { category: 'event', label: 'USER_EVENT', description: 'Voice request received' },
      { category: 'orchestrator', label: 'ORCHESTRATOR', description: 'Planning: test → summarize' },
      { category: 'validator', label: 'VALIDATOR', description: 'Execution plan validated' },
      { category: 'plugin', label: 'terminal.EXECUTE', description: 'Running "pnpm test"' },
      { category: 'result', label: 'RESULT', description: '142 passed, 0 failed' },
    ],
  },
]

/** Seed events so the monitor is populated on first render. */
export function seedEvents(now = Date.now()): NexusEvent[] {
  const base: Omit<NexusEvent, 'id' | 'timestamp'>[] = [
    { category: 'event', label: 'SESSION', description: 'Console session initialized' },
    { category: 'orchestrator', label: 'ORCHESTRATOR', description: 'Runtime handshake complete' },
    { category: 'plugin', label: 'plugins.LOADED', description: '6 plugins registered' },
    { category: 'result', label: 'READY', description: 'Nexus runtime ready' },
  ]
  return base.map((e, i) => ({
    ...e,
    id: nextId('seed'),
    timestamp: now - (base.length - i) * 2400,
  }))
}

/** Seed the most-recent interaction shown near the voice panel. */
export function seedInteractions(now = Date.now()): Interaction[] {
  return [
    {
      id: nextId('seed-int'),
      role: 'user',
      text: 'What is the current system status?',
      timestamp: now - 18000,
    },
    {
      id: nextId('seed-int'),
      role: 'nexus',
      text: 'All systems are operational. Latency is nominal.',
      timestamp: now - 15000,
    },
  ]
}

/** The linear runtime flow shown in DEBUG mode. */
export const DEBUG_FLOW: { label: string; category: EventCategory }[] = [
  { label: 'EVENT RECEIVED', category: 'event' },
  { label: 'ORCHESTRATOR', category: 'orchestrator' },
  { label: 'EXECUTION PLAN', category: 'orchestrator' },
  { label: 'VALIDATION', category: 'validator' },
  { label: 'PLUGIN EXECUTION', category: 'plugin' },
  { label: 'RESULT', category: 'result' },
]
