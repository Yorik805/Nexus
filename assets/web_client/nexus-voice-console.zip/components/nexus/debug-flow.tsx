'use client'

import type { NexusEvent } from '@/lib/nexus/types'

/**
 * Reserved DEBUG-mode panel. Intentionally left empty for now — it keeps its
 * footprint so a future execution-trace visualization can drop in here without
 * shifting the surrounding layout.
 *
 * `events` is kept in the signature so the real trace can consume it later.
 */
export function DebugFlow({ events: _events }: { events: NexusEvent[] }) {
  return (
    <section
      aria-label="Execution flow"
      className="border-b border-border px-4 py-4"
    >
      <div className="min-h-64" />
    </section>
  )
}
