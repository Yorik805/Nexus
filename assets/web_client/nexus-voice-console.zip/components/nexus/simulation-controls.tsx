'use client'

import { ChevronDown, FlaskConical, Play } from 'lucide-react'
import { useState } from 'react'
import { cn } from '@/lib/utils'
import type { ConnectionState, VoiceState } from '@/lib/nexus/types'

/**
 * DEMO-ONLY control panel. Lets a reviewer preview every voice/connection
 * state without waiting for the scripted loop. None of this exists in the
 * real console — states are driven by Nexus + microphone events.
 */
const VOICE_STATES: VoiceState[] = [
  'idle',
  'listening',
  'user_speaking',
  'processing',
  'nexus_speaking',
  'interruption',
  'mic_disabled',
  'error',
]

const CONNECTION_STATES: ConnectionState[] = [
  'connected',
  'connecting',
  'retrying',
  'disconnected',
  'error',
]

export function SimulationControls({
  autoRun,
  onPreviewVoice,
  onPreviewConnection,
  onResume,
}: {
  autoRun: boolean
  onPreviewVoice: (s: VoiceState) => void
  onPreviewConnection: (c: ConnectionState) => void
  onResume: () => void
}) {
  const [open, setOpen] = useState(false)

  return (
    <div className="border-t border-border">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-4 py-3 font-mono text-[10px] tracking-[0.3em] text-muted-foreground transition-colors hover:text-foreground"
        aria-expanded={open}
      >
        <span className="flex items-center gap-2">
          <FlaskConical className="size-3.5 text-cat-validator" />
          DEMO CONTROLS
        </span>
        <ChevronDown className={cn('size-3.5 transition-transform', open && 'rotate-180')} />
      </button>

      {open && (
        <div className="flex flex-col gap-4 px-4 pb-4">
          <p className="text-pretty text-[11px] leading-relaxed text-muted-foreground/80">
            Preview any state below. This pauses the scripted simulation.
          </p>

          <ControlGroup title="VOICE STATE">
            {VOICE_STATES.map((s) => (
              <PillButton key={s} onClick={() => onPreviewVoice(s)}>
                {s.replace('_', ' ')}
              </PillButton>
            ))}
          </ControlGroup>

          <ControlGroup title="CONNECTION">
            {CONNECTION_STATES.map((c) => (
              <PillButton key={c} onClick={() => onPreviewConnection(c)}>
                {c}
              </PillButton>
            ))}
          </ControlGroup>

          <button
            type="button"
            onClick={onResume}
            className={cn(
              'flex items-center justify-center gap-2 rounded-md border px-3 py-2 font-mono text-[11px] tracking-widest transition-colors',
              autoRun
                ? 'border-cat-result/40 bg-cat-result/10 text-cat-result'
                : 'border-primary/40 bg-primary/15 text-primary hover:bg-primary/25',
            )}
          >
            <Play className="size-3.5" />
            {autoRun ? 'SIMULATION RUNNING' : 'RESUME SIMULATION'}
          </button>
        </div>
      )}
    </div>
  )
}

function ControlGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-2 font-mono text-[9px] tracking-[0.3em] text-muted-foreground/60">
        {title}
      </p>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  )
}

function PillButton({
  children,
  onClick,
}: {
  children: React.ReactNode
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="rounded border border-border bg-background/50 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
    >
      {children}
    </button>
  )
}
