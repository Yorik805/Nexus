'use client'

import { useState } from 'react'
import type { ConsoleMode, NexusStatus } from '@/lib/nexus/types'
import { useNexusSimulation } from '@/lib/nexus/use-nexus-simulation'
import { ConsoleHeader } from './console-header'
import { VoiceInterface } from './voice-interface'
import { InteractionHistory } from './interaction-history'
import { EventMonitor } from './event-monitor'
import { ConnectionStatus } from './connection-status'
import { DebugFlow } from './debug-flow'
import { StatusBar } from './status-bar'
import { SimulationControls } from './simulation-controls'

export function NexusConsole() {
  const sim = useNexusSimulation()
  const [mode, setMode] = useState<ConsoleMode>('normal')

  const status: NexusStatus = {
    connection: sim.connection,
    // PLACEHOLDER endpoint label — never a real address in this prototype.
    endpointLabel: 'nexus.local:7878',
    latencyMs: sim.latencyMs,
    lastCommunication: sim.lastCommunication,
  }

  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground lg:h-dvh lg:overflow-hidden">
      <ConsoleHeader
        connection={sim.connection}
        micEnabled={sim.micEnabled}
        mode={mode}
        onRetry={sim.retry}
        onToggleMic={sim.toggleMic}
        onModeChange={setMode}
      />

      <main className="flex flex-1 flex-col lg:min-h-0 lg:flex-row">
        {/* Primary column: voice interface */}
        <div className="flex flex-col lg:min-h-0 lg:flex-1">
          <div className="bg-console-grid flex min-h-[58vh] items-center justify-center lg:min-h-0 lg:flex-1">
            <VoiceInterface
              voiceState={sim.voiceState}
              liveTranscript={sim.liveTranscript}
              spokenResponse={sim.spokenResponse}
              onStopSpeaking={sim.stopSpeaking}
              onInterrupt={sim.triggerInterruption}
            />
          </div>
          <InteractionHistory interactions={sim.interactions} />
        </div>

        {/* Sidebar: status + monitor */}
        <aside className="flex min-h-0 w-full flex-col overflow-y-auto border-t border-border bg-card/20 lg:w-[360px] lg:border-l lg:border-t-0">
          <ConnectionStatus status={status} />
          {mode === 'debug' && <DebugFlow events={sim.events} />}
          <div className="min-h-80 flex-1">
            <EventMonitor events={sim.events} />
          </div>
          <SimulationControls
            autoRun={sim.autoRun}
            onPreviewVoice={sim.previewVoiceState}
            onPreviewConnection={sim.previewConnection}
            onResume={sim.resumeAuto}
          />
        </aside>
      </main>

      <StatusBar
        connection={sim.connection}
        voiceState={sim.voiceState}
        mode={mode}
        latencyMs={sim.latencyMs}
      />
    </div>
  )
}
